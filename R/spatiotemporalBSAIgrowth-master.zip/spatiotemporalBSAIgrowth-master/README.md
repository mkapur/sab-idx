# spatiotemporal_BSAIgrowth
Project for analyzing growth data with VAST
